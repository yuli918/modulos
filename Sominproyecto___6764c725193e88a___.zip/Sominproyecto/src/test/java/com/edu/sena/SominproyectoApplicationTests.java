package com.edu.sena;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SominproyectoApplicationTests {

	@Test
	void contextLoads() {
	}

}
