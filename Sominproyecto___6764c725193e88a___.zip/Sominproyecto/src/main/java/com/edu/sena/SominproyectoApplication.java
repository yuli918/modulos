package com.edu.sena;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SominproyectoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SominproyectoApplication.class, args);
	}

}
